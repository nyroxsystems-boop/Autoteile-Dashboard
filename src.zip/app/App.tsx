import { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { DashboardSidebar } from './components/DashboardSidebar';
import { DashboardHeader } from './components/DashboardHeader';
import { CommandPalette } from './components/CommandPalette';
import { ShortcutsOverlay } from './components/ShortcutsOverlay';
import { ToastProvider } from './components/ToastProvider';
import { useKeyboardShortcuts } from './hooks/useKeyboardShortcuts';
import { HeuteView } from './views/HeuteView';
import { AuftraegeView } from './views/AuftraegeView';
import { AngeboteView } from './views/AngeboteView';
import { PreisprofileView } from './views/PreisprofileView';
import { LieferantenView } from './views/LieferantenView';
import { StatusView } from './views/StatusView';
import { CustomersInquiriesView } from './views/CustomersInquiriesView';
import { DocumentsInvoicesView } from './views/DocumentsInvoicesView';
import { WarehouseView } from './views/WarehouseView';
import { SettingsView } from './views/SettingsView';

export default function App() {
  const [activeView, setActiveView] = useState('heute');
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [language, setLanguage] = useState<'de' | 'en'>('de');
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const [notificationCount, setNotificationCount] = useState(3);

  // Load theme from localStorage
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') as 'light' | 'dark' | null;
    const savedLanguage = localStorage.getItem('language') as 'de' | 'en' | null;
    
    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.classList.toggle('dark', savedTheme === 'dark');
    }
    
    if (savedLanguage) {
      setLanguage(savedLanguage);
    }

    // Welcome message
    const hasSeenWelcome = localStorage.getItem('hasSeenWelcome');
    if (!hasSeenWelcome) {
      setTimeout(() => {
        toast.success('Willkommen im Dashboard! Drücke ⌘K für schnellen Zugriff.', {
          duration: 6000,
        });
        localStorage.setItem('hasSeenWelcome', 'true');
      }, 500);
    }
  }, []);

  // Handle theme change
  const handleThemeChange = (newTheme: 'light' | 'dark') => {
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
  };

  // Handle language change
  const handleLanguageChange = (newLang: 'de' | 'en') => {
    setLanguage(newLang);
    localStorage.setItem('language', newLang);
  };

  // Handle view navigation
  const handleNavigate = (view: string) => {
    setActiveView(view);
    const viewNames: Record<string, string> = {
      heute: 'Heute',
      kunden: 'Kunden & Anfragen',
      angebote: 'Angebote',
      auftraege: 'Aufträge',
      preise: 'Preisprofile',
      belege: 'Belege & Rechnungen',
      lieferanten: 'Lieferanten',
      status: 'Status & Analytics',
      warenwirtschaft: 'Warenwirtschaft',
    };
    toast.success(`Zu ${viewNames[view] || view} gewechselt`);
  };

  // Settings modal handler
  const handleOpenSettings = () => {
    const event = new CustomEvent('open-settings');
    window.dispatchEvent(event);
  };

  // Setup keyboard shortcuts
  useKeyboardShortcuts({
    onNavigate: handleNavigate,
    onOpenCommandPalette: () => setCommandPaletteOpen(true),
    onOpenSettings: handleOpenSettings,
  });

  // Listen for custom events
  useEffect(() => {
    const handleShowShortcuts = () => setShortcutsOpen(true);
    const handleOpenSettingsEvent = () => {
      // Trigger settings modal in header
      const event = new MouseEvent('click', { bubbles: true });
      // This is handled by the header component
    };

    window.addEventListener('show-shortcuts', handleShowShortcuts);
    window.addEventListener('open-settings', handleOpenSettingsEvent);

    return () => {
      window.removeEventListener('show-shortcuts', handleShowShortcuts);
      window.removeEventListener('open-settings', handleOpenSettingsEvent);
    };
  }, []);

  const renderView = () => {
    switch (activeView) {
      case 'heute':
        return <HeuteView onNavigate={setActiveView} />;
      case 'kunden':
        return <CustomersInquiriesView onNavigate={setActiveView} />;
      case 'auftraege':
        return <AuftraegeView />;
      case 'angebote':
        return <AngeboteView />;
      case 'preise':
        return <PreisprofileView />;
      case 'belege':
        return <DocumentsInvoicesView />;
      case 'warenwirtschaft':
        return <WarehouseView />;
      case 'lieferanten':
        return <LieferantenView />;
      case 'status':
        return <StatusView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <HeuteView onNavigate={setActiveView} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <DashboardSidebar
        activeView={activeView}
        onNavigate={setActiveView}
        botStatus="online"
        environment="demo"
      />

      {/* Header */}
      <DashboardHeader
        theme={theme}
        onThemeChange={handleThemeChange}
        language={language}
        onLanguageChange={handleLanguageChange}
        userName="Max Mustermann"
        userEmail="max@autoteile-shop.de"
        companyName="Autoteile Shop GmbH"
        notificationCount={notificationCount}
        onOpenCommandPalette={() => setCommandPaletteOpen(true)}
        onNavigate={setActiveView}
      />

      {/* Main Content with Container */}
      <main className="ml-20 mt-16">
        <div className="max-w-[1440px] mx-auto px-12 py-12">
          {renderView()}
        </div>
      </main>

      {/* Command Palette */}
      <CommandPalette
        open={commandPaletteOpen}
        onOpenChange={setCommandPaletteOpen}
        onNavigate={handleNavigate}
        theme={theme}
      />

      {/* Shortcuts Overlay */}
      <ShortcutsOverlay
        open={shortcutsOpen}
        onClose={() => setShortcutsOpen(false)}
      />

      {/* Toast Provider */}
      <ToastProvider theme={theme} />
    </div>
  );
}