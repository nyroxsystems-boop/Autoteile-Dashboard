import { useState } from 'react';
import { Search, Package, CheckCircle2, Clock, AlertCircle, CheckCircle, TrendingUp, AlertTriangle } from 'lucide-react';
import { StatusChip } from '../components/StatusChip';
import { Sparkline } from '../components/Sparkline';

interface WarehouseSystem {
  id: string;
  name: string;
  type: 'shop' | 'wws' | 'supplier';
  status: 'connected' | 'syncing' | 'error';
  inventory: number;
  lastSync: string;
  deliveryTime: string;
}

const mockSystems: WarehouseSystem[] = [
  {
    id: '1',
    name: 'ATU Autoteile',
    type: 'shop',
    status: 'connected',
    inventory: 15234,
    lastSync: 'vor 2 Min',
    deliveryTime: '1-2 Tage',
  },
  {
    id: '2',
    name: 'TecDoc Catalog',
    type: 'supplier',
    status: 'connected',
    inventory: 98456,
    lastSync: 'vor 5 Min',
    deliveryTime: '2-3 Tage',
  },
  {
    id: '3',
    name: 'Internes WWS',
    type: 'wws',
    status: 'syncing',
    inventory: 3421,
    lastSync: 'läuft...',
    deliveryTime: 'sofort',
  },
  {
    id: '4',
    name: 'Mister Auto',
    type: 'shop',
    status: 'connected',
    inventory: 28934,
    lastSync: 'vor 8 Min',
    deliveryTime: '1-3 Tage',
  },
  {
    id: '5',
    name: 'Autodoc',
    type: 'shop',
    status: 'error',
    inventory: 0,
    lastSync: 'vor 2 Std',
    deliveryTime: '-',
  },
];

const typeLabels = {
  shop: 'Online-Shop',
  wws: 'Warenwirtschaft',
  supplier: 'Lieferant',
};

const statusConfig = {
  connected: { label: 'Verbunden', variant: 'success' as const, icon: CheckCircle2 },
  syncing: { label: 'Synchronisiert', variant: 'processing' as const, icon: Clock },
  error: { label: 'Fehler', variant: 'error' as const, icon: AlertCircle },
};

export function WarehouseView() {
  const [searchQuery, setSearchQuery] = useState('');
  const [showOnlyErrors, setShowOnlyErrors] = useState(false);

  const filteredSystems = mockSystems.filter(system => {
    const matchesSearch = system.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = !showOnlyErrors || system.status === 'error';
    return matchesSearch && matchesFilter;
  });

  const stats = {
    connected: mockSystems.filter(s => s.status === 'connected').length,
    totalInventory: mockSystems.reduce((sum, s) => sum + s.inventory, 0),
    errors: mockSystems.filter(s => s.status === 'error').length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-foreground mb-2">Warenwirtschaft</h1>
        <p className="text-muted-foreground">
          Bestände überwachen und Bestellungen auslösen
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-6">
        {/* Aktive Systeme - Premium Glassmorphism Card */}
        <div className="group relative p-6 rounded-2xl bg-gradient-to-br from-green-500/10 via-green-400/5 to-transparent border border-green-500/20 hover:border-green-500/40 backdrop-blur-xl hover:shadow-[0_20px_60px_-15px_rgba(34,197,94,0.3)] hover:-translate-y-1 transition-all duration-500 cursor-pointer overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 via-transparent to-green-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          <div className="absolute -top-12 -right-12 w-32 h-32 bg-green-400/20 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-all duration-700" />
          
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-5">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-green-500 to-green-600 shadow-lg shadow-green-500/25 flex items-center justify-center group-hover:scale-110 group-hover:shadow-xl group-hover:shadow-green-500/40 transition-all duration-300">
                <CheckCircle className="w-7 h-7 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-500/10 border border-green-500/20">
                <span className="text-xs font-bold text-green-600">Online</span>
              </div>
            </div>
            
            <div className="space-y-2 mb-4">
              <div className="text-sm font-semibold text-muted-foreground/80 tracking-wide uppercase">Aktive Systeme</div>
              <div className="text-5xl font-bold bg-gradient-to-br from-green-600 to-green-500 bg-clip-text text-transparent tabular-nums tracking-tight">
                {stats.connected}
              </div>
            </div>
            
            <div className="mb-4 p-3 rounded-xl bg-gradient-to-br from-green-500/5 to-green-600/10 border border-green-500/10">
              <Sparkline 
                data={[3, 4, 4, 4, 4, 4, 4]} 
                color="#22c55e"
                height={32}
              />
            </div>
            
            <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              Alle verbunden
            </div>
          </div>
        </div>

        {/* Gesamt Bestand - Premium Glassmorphism Card */}
        <div className="group relative p-6 rounded-2xl bg-gradient-to-br from-purple-500/10 via-purple-400/5 to-transparent border border-purple-500/20 hover:border-purple-500/40 backdrop-blur-xl hover:shadow-[0_20px_60px_-15px_rgba(168,85,247,0.3)] hover:-translate-y-1 transition-all duration-500 cursor-pointer overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 via-transparent to-purple-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          <div className="absolute -top-12 -right-12 w-32 h-32 bg-purple-400/20 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-all duration-700" />
          
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-5">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500 to-purple-600 shadow-lg shadow-purple-500/25 flex items-center justify-center group-hover:scale-110 group-hover:shadow-xl group-hover:shadow-purple-500/40 transition-all duration-300">
                <Package className="w-7 h-7 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-500/10 border border-green-500/20">
                <TrendingUp className="w-3.5 h-3.5 text-green-600" strokeWidth={2.5} />
                <span className="text-xs font-bold text-green-600">+5%</span>
              </div>
            </div>
            
            <div className="space-y-2 mb-4">
              <div className="text-sm font-semibold text-muted-foreground/80 tracking-wide uppercase">Gesamt Bestand</div>
              <div className="text-5xl font-bold bg-gradient-to-br from-purple-600 to-purple-500 bg-clip-text text-transparent tabular-nums tracking-tight">
                {stats.totalInventory.toLocaleString('de-DE')}
              </div>
            </div>
            
            <div className="mb-4 p-3 rounded-xl bg-gradient-to-br from-purple-500/5 to-purple-600/10 border border-purple-500/10">
              <Sparkline 
                data={[138000, 141000, 139000, 143000, 142000, 144000, 146045]} 
                color="#a855f7"
                height={32}
              />
            </div>
            
            <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <div className="w-1.5 h-1.5 rounded-full bg-[var(--status-success)] animate-pulse" />
              Artikel verfügbar
            </div>
          </div>
        </div>

        {/* Probleme - Premium Glassmorphism Card */}
        <div 
          onClick={() => setShowOnlyErrors(!showOnlyErrors)}
          className={`group relative p-6 rounded-2xl bg-gradient-to-br from-red-500/10 via-red-400/5 to-transparent border backdrop-blur-xl hover:-translate-y-1 transition-all duration-500 cursor-pointer overflow-hidden ${
            showOnlyErrors
              ? 'border-red-500/60 shadow-[0_20px_60px_-15px_rgba(239,68,68,0.4)] ring-2 ring-red-500/30'
              : 'border-red-500/20 hover:border-red-500/40 hover:shadow-[0_20px_60px_-15px_rgba(239,68,68,0.3)]'
          }`}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 via-transparent to-red-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          <div className="absolute -top-12 -right-12 w-32 h-32 bg-red-400/20 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-all duration-700" />
          
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-5">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-red-500 to-red-600 shadow-lg shadow-red-500/25 flex items-center justify-center group-hover:scale-110 group-hover:shadow-xl group-hover:shadow-red-500/40 transition-all duration-300">
                <AlertTriangle className="w-7 h-7 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-red-500/10 border border-red-500/20">
                <span className="text-xs font-bold text-red-600">⚠️</span>
              </div>
            </div>
            
            <div className="space-y-2 mb-4">
              <div className="text-sm font-semibold text-muted-foreground/80 tracking-wide uppercase">Probleme</div>
              <div className="text-5xl font-bold bg-gradient-to-br from-red-600 to-red-500 bg-clip-text text-transparent tabular-nums tracking-tight">
                {stats.errors}
              </div>
            </div>
            
            <div className="mb-4 p-3 rounded-xl bg-gradient-to-br from-red-500/5 to-red-600/10 border border-red-500/10">
              <Sparkline 
                data={[0, 0, 1, 0, 0, 1, 1]} 
                color="#ef4444"
                height={32}
              />
            </div>
            
            <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
              Sync-Fehler
            </div>
          </div>
        </div>
      </div>

      {/* Info Box */}
      <div className="p-5 rounded-xl border border-[var(--status-processing-border)] bg-[var(--status-processing-bg)]">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-[var(--status-processing)] flex items-center justify-center flex-shrink-0">
            <Package className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="font-medium text-foreground mb-1">WWS-Anbindung</div>
            <div className="text-sm text-muted-foreground">
              Hier sehen Sie Bestände und können Bestellungen auslösen. Die technische Konfiguration erfolgt im Admin-Dashboard.
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="System suchen..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full h-10 pl-10 pr-4 rounded-lg border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
        />
      </div>

      {/* Systems List */}
      <div className="space-y-3">
        {filteredSystems.map((system) => {
          const StatusIcon = statusConfig[system.status].icon;
          
          return (
            <div
              key={system.id}
              className="p-5 rounded-lg border border-border bg-card hover:bg-accent transition-all duration-150"
            >
              <div className="flex items-start gap-4">
                {/* Icon */}
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Package className="w-5 h-5 text-primary" />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div>
                      <div className="font-medium text-foreground mb-1">{system.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {typeLabels[system.type]}
                      </div>
                    </div>
                    <StatusChip 
                      status={statusConfig[system.status].variant}
                      label={statusConfig[system.status].label}
                      size="sm"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-6">
                    <div>
                      <div className="text-xs text-muted-foreground mb-1">Bestand</div>
                      <div className="font-semibold text-foreground tabular-nums">
                        {system.inventory.toLocaleString('de-DE')}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground mb-1">Lieferzeit</div>
                      <div className="font-medium text-foreground">
                        {system.deliveryTime}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-muted-foreground mb-1">Letzte Aktualisierung</div>
                      <div className="font-medium text-foreground">
                        {system.lastSync}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
        {filteredSystems.length === 0 && (
          <div className="py-16 text-center">
            <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <Search className="w-6 h-6 text-muted-foreground" />
            </div>
            <div className="font-medium text-foreground mb-1">Keine Systeme gefunden</div>
            <div className="text-sm text-muted-foreground">
              Versuchen Sie es mit anderen Suchbegriffen
            </div>
          </div>
        )}
      </div>
    </div>
  );
}