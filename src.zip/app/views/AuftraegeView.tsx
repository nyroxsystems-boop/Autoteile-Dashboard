import { useState } from 'react';
import { StatusChip } from '../components/StatusChip';
import { OrderTimeline } from '../components/OrderTimeline';
import { Button } from '../components/ui/button';
import { Car, MessageSquare, User, Truck, Clock, Download } from 'lucide-react';

// Mock data
const orders = [
  {
    id: 'ORD-001',
    customer: 'Autowerkstatt Schmidt GmbH',
    contact: 'Hans Schmidt',
    vehicle: 'VW Golf 8 GTI',
    oem: '5Q0615301G',
    part: 'Bremsscheibe vorne',
    status: 'waiting' as const,
    statusLabel: 'Wartet auf Kunde',
    channel: 'WhatsApp',
    offers: [
      { supplier: 'ATR Autoteile', price: 89.99, delivery: '1-2 Tage', stock: 'Lagernd', customerPrice: 119.99 },
      { supplier: 'Teile24', price: 92.50, delivery: '2-3 Tage', stock: 'Lagernd', customerPrice: 124.99 },
      { supplier: 'KFZ-Discount', price: 85.00, delivery: '3-4 Tage', stock: 'Auf Anfrage', customerPrice: 114.99 },
    ],
    timeline: [
      { label: 'Anfrage empfangen', completed: true },
      { label: 'OEM geprüft', completed: true },
      { label: 'Angebote eingeholt', completed: true },
      { label: 'Kunde wartet auf Angebot', completed: false, current: true },
      { label: 'Auftrag bestätigt', completed: false },
      { label: 'Beleg erstellt', completed: false },
    ],
    primaryAction: 'An Kunden senden'
  },
  {
    id: 'ORD-002',
    customer: 'KFZ Müller',
    contact: 'Peter Müller',
    vehicle: 'Audi A4 B9',
    oem: '8W0698151AB',
    part: 'Bremsbeläge hinten',
    status: 'processing' as const,
    statusLabel: 'In Bearbeitung',
    channel: 'WhatsApp',
    offers: [
      { supplier: 'Premium Parts', price: 145.00, delivery: '1 Tag', stock: 'Lagernd', customerPrice: 189.99 },
      { supplier: 'Auto Express', price: 139.99, delivery: '2 Tage', stock: 'Lagernd', customerPrice: 179.99 },
    ],
    timeline: [
      { label: 'Anfrage empfangen', completed: true },
      { label: 'OEM geprüft', completed: true },
      { label: 'Angebote einholen', completed: false, current: true },
      { label: 'Kunde wartet auf Angebot', completed: false },
      { label: 'Auftrag bestätigt', completed: false },
      { label: 'Beleg erstellt', completed: false },
    ],
    primaryAction: 'Angebote auswählen'
  },
];

export function AuftraegeView() {
  const [selectedOrder, setSelectedOrder] = useState(orders[0]);

  return (
    <div className="grid grid-cols-12 gap-6 h-[calc(100vh-8rem)]">
      {/* Order List - Left Side */}
      <div className="col-span-5 space-y-6 overflow-y-auto pr-2">
        <div>
          <h1>Aufträge</h1>
          <p className="text-muted-foreground mt-2 leading-relaxed">
            Alle laufenden Bestellvorgänge
          </p>
        </div>

        <div className="space-y-3">
          {orders.map((order) => (
            <button
              key={order.id}
              onClick={() => setSelectedOrder(order)}
              className={`
                w-full p-5 rounded-xl border transition-all duration-200 text-left
                ${selectedOrder.id === order.id
                  ? 'border-primary bg-primary/5 shadow-md ring-1 ring-primary/20'
                  : 'border-border bg-card hover:border-primary/40 hover:bg-muted/30 hover:shadow-sm'
                }
              `}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2.5 mb-1.5">
                    <MessageSquare className="w-4 h-4 text-[var(--status-success)]" />
                    <span className="font-medium">{order.customer}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground" style={{ fontSize: '0.875rem' }}>
                    <Car className="w-3.5 h-3.5" />
                    <span>{order.vehicle}</span>
                  </div>
                </div>
                <StatusChip status={order.status} label={order.statusLabel} size="sm" />
              </div>
              <div className="flex items-center gap-2">
                <code className="px-2.5 py-1 bg-muted rounded-md text-xs font-mono font-medium">
                  {order.oem}
                </code>
                <span className="text-muted-foreground" style={{ fontSize: '0.875rem' }}>
                  {order.part}
                </span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Order Details - Right Side */}
      <div className="col-span-7 bg-card border border-border rounded-xl p-8 overflow-y-auto shadow-sm">
        {selectedOrder && (
          <div className="space-y-10">
            {/* Header */}
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <h2>{selectedOrder.customer}</h2>
                <StatusChip status={selectedOrder.status} label={selectedOrder.statusLabel} />
              </div>
              <p className="text-muted-foreground">{selectedOrder.id}</p>
            </div>

            {/* Context Section */}
            <div className="space-y-5">
              <h3>Kontext</h3>
              <div className="grid grid-cols-2 gap-6">
                <div className="flex items-start gap-3">
                  <User className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <div className="text-muted-foreground mb-1" style={{ fontSize: '0.875rem' }}>Ansprechpartner</div>
                    <div className="font-medium">{selectedOrder.contact}</div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <MessageSquare className="w-5 h-5 text-[var(--status-success)] mt-0.5" />
                  <div>
                    <div className="text-muted-foreground mb-1" style={{ fontSize: '0.875rem' }}>Eingangskanal</div>
                    <div className="font-medium">{selectedOrder.channel}</div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Car className="w-5 h-5 text-muted-foreground mt-0.5" />
                  <div>
                    <div className="text-muted-foreground mb-1" style={{ fontSize: '0.875rem' }}>Fahrzeug</div>
                    <div className="font-medium">{selectedOrder.vehicle}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Parts & OEM */}
            <div className="space-y-5">
              <h3>Teile & OEM</h3>
              <div className="p-5 bg-muted/50 rounded-xl border border-border">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-muted-foreground mb-2" style={{ fontSize: '0.875rem' }}>OEM-Nummer</div>
                    <code className="px-3 py-1.5 bg-background border border-border rounded-md font-mono font-medium">
                      {selectedOrder.oem}
                    </code>
                  </div>
                  <div className="px-3 py-1.5 bg-[var(--status-success-bg)] text-[var(--status-success-fg)] rounded-md text-sm font-medium border border-[var(--status-success-border)]">
                    Geprüft
                  </div>
                </div>
                <div className="mt-4 font-medium">{selectedOrder.part}</div>
              </div>
            </div>

            {/* Offers */}
            <div className="space-y-5">
              <h3>Angebote (Top 3)</h3>
              <div className="space-y-3">
                {selectedOrder.offers.map((offer, index) => (
                  <div
                    key={index}
                    className={`
                      p-5 rounded-xl border transition-all
                      ${index === 0 
                        ? 'border-[var(--status-success-border)] bg-[var(--status-success-bg)]/30' 
                        : 'border-border bg-background'
                      }
                    `}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="font-semibold mb-2">{offer.supplier}</div>
                        <div className="flex items-center gap-4 text-muted-foreground" style={{ fontSize: '0.875rem' }}>
                          <div className="flex items-center gap-1.5">
                            <Truck className="w-3.5 h-3.5" />
                            <span>{offer.delivery}</span>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5" />
                            <span>{offer.stock}</span>
                          </div>
                        </div>
                      </div>
                      {index === 0 && (
                        <div className="px-2.5 py-1 bg-[var(--status-success)] text-white rounded-md text-xs font-semibold">
                          Empfohlen
                        </div>
                      )}
                    </div>
                    <div className="flex items-end justify-between">
                      <div>
                        <div className="text-muted-foreground mb-1" style={{ fontSize: '0.875rem' }}>Basispreis</div>
                        <div className="text-muted-foreground font-medium">€{offer.price.toFixed(2)}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-muted-foreground mb-1" style={{ fontSize: '0.875rem' }}>Kundenpreis</div>
                        <div className="tabular-nums tracking-tight" style={{ fontSize: '1.75rem', fontWeight: 600 }}>
                          €{offer.customerPrice.toFixed(2)}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-muted-foreground">
                Preisgestaltung wird zentral verwaltet
              </p>
            </div>

            {/* Timeline */}
            <div className="space-y-5">
              <h3>Fortschritt</h3>
              <OrderTimeline steps={selectedOrder.timeline} />
            </div>

            {/* Primary Action */}
            <div className="pt-6 border-t border-border">
              <Button size="lg" className="w-full">
                {selectedOrder.primaryAction}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}