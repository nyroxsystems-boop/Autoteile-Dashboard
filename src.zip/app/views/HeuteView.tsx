import { StatusChip } from '../components/StatusChip';
import { TaskCard } from '../components/TaskCard';
import { PageHeader } from '../components/PageHeader';
import { MetricCard } from '../components/MetricCard';
import { DataTable } from '../components/DataTable';
import { RevenueChart } from '../components/RevenueChart';
import { TopCustomers } from '../components/TopCustomers';
import { ActivityFeed } from '../components/ActivityFeed';
import { Button } from '../components/ui/button';
import { Package, MessageSquare, TrendingUp, Clock, CheckCircle2, AlertCircle, FileText, DollarSign, ShoppingCart, Search, Receipt } from 'lucide-react';
import { useState } from 'react';

interface HeuteViewProps {
  onNavigate: (view: string, filter?: string) => void;
}

// Mock data
const currentTasks = [
  {
    id: 1,
    customer: 'Autowerkstatt Schmidt GmbH',
    vehicle: 'VW Golf 8',
    oem: '5Q0615301G',
    status: 'waiting' as const,
    statusLabel: 'Wartet auf Kunde',
    action: 'Nachfassen'
  },
  {
    id: 2,
    customer: 'KFZ Müller',
    vehicle: 'Audi A4 B9',
    oem: '8W0698151AB',
    status: 'processing' as const,
    statusLabel: 'Angebot erstellen',
    action: 'Angebote auswählen'
  },
  {
    id: 3,
    customer: 'AutoService Berlin',
    vehicle: 'BMW 3er G20',
    oem: '34216887884',
    status: 'waiting' as const,
    statusLabel: 'Wartet auf Kunde',
    action: 'Angebot senden'
  },
  {
    id: 4,
    customer: 'Meisterwerkstatt Koch',
    vehicle: 'Mercedes C-Klasse W206',
    oem: 'A0004209100',
    status: 'processing' as const,
    statusLabel: 'In Bearbeitung',
    action: 'Beleg erzeugen'
  },
  {
    id: 5,
    customer: 'Auto Reparatur Plus',
    vehicle: 'Ford Focus',
    oem: '2137608',
    status: 'error' as const,
    statusLabel: 'Fehler',
    action: 'Problem melden'
  },
];

export function HeuteView({
  onNavigate
}: HeuteViewProps) {
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | '1y'>('30d');

  // Chart data - last 30 days
  const chartData = [
    { date: '24.11', revenue: 1200, orders: 8 },
    { date: '25.11', revenue: 1850, orders: 12 },
    { date: '26.11', revenue: 2100, orders: 14 },
    { date: '27.11', revenue: 1650, orders: 11 },
    { date: '28.11', revenue: 2400, orders: 16 },
    { date: '29.11', revenue: 1900, orders: 13 },
    { date: '30.11', revenue: 2650, orders: 18 },
    { date: '01.12', revenue: 2200, orders: 15 },
    { date: '02.12', revenue: 2800, orders: 19 },
    { date: '03.12', revenue: 2450, orders: 17 },
    { date: '04.12', revenue: 3100, orders: 21 },
    { date: '05.12', revenue: 2750, orders: 18 },
    { date: '06.12', revenue: 2900, orders: 20 },
    { date: '07.12', revenue: 2600, orders: 17 },
    { date: '08.12', revenue: 3200, orders: 22 },
    { date: '09.12', revenue: 2850, orders: 19 },
    { date: '10.12', revenue: 2950, orders: 20 },
    { date: '11.12', revenue: 3400, orders: 23 },
    { date: '12.12', revenue: 3100, orders: 21 },
    { date: '13.12', revenue: 2700, orders: 18 },
    { date: '14.12', revenue: 2950, orders: 20 },
    { date: '15.12', revenue: 3250, orders: 22 },
    { date: '16.12', revenue: 2900, orders: 19 },
    { date: '17.12', revenue: 3150, orders: 21 },
    { date: '18.12', revenue: 3500, orders: 24 },
    { date: '19.12', revenue: 3300, orders: 22 },
    { date: '20.12', revenue: 2850, orders: 19 },
    { date: '21.12', revenue: 3100, orders: 21 },
    { date: '22.12', revenue: 3450, orders: 23 },
    { date: 'Heute', revenue: 2847, orders: 19 },
  ];

  // Top customers data
  const topCustomers = [
    { name: 'Autowerkstatt Schmidt GmbH', revenue: '€8,450', orders: 24, change: 15, avatar: 'AS' },
    { name: 'KFZ Müller', revenue: '€6,230', orders: 18, change: 8, avatar: 'KM' },
    { name: 'AutoService Berlin', revenue: '€5,890', orders: 16, change: 22, avatar: 'AB' },
    { name: 'Meisterwerkstatt Koch', revenue: '€4,670', orders: 14, change: -3, avatar: 'MK' },
    { name: 'Auto Reparatur Plus', revenue: '€4,120', orders: 12, change: 12, avatar: 'AR' },
  ];

  // Activity feed data
  const activities = [
    {
      id: '1',
      type: 'message' as const,
      customer: 'Autowerkstatt Schmidt',
      description: 'Neue WhatsApp-Anfrage für Bremsscheiben VW Golf 8',
      time: 'vor 2 Min',
      status: 'processing' as const,
    },
    {
      id: '2',
      type: 'quote' as const,
      customer: 'KFZ Müller',
      description: 'Angebot erstellt und versendet - €245,00',
      time: 'vor 8 Min',
      status: 'waiting' as const,
    },
    {
      id: '3',
      type: 'order' as const,
      customer: 'AutoService Berlin',
      description: 'Bestellung aufgegeben - BMW Bremsbeläge',
      time: 'vor 15 Min',
      status: 'processing' as const,
    },
    {
      id: '4',
      type: 'completed' as const,
      customer: 'Meisterwerkstatt Koch',
      description: 'Auftrag abgeschlossen - €380,00',
      time: 'vor 23 Min',
      status: 'success' as const,
    },
    {
      id: '5',
      type: 'message' as const,
      customer: 'Auto Reparatur Plus',
      description: 'Kunde fragt nach Lieferstatus',
      time: 'vor 45 Min',
      status: 'waiting' as const,
    },
    {
      id: '6',
      type: 'quote' as const,
      customer: 'Werkstatt Hoffmann',
      description: 'Angebot angenommen - €520,00',
      time: 'vor 1 Std',
      status: 'success' as const,
    },
  ];

  // Task Cards Data - was heute blockiert oder Geld bringt
  const taskCards = [
    { 
      title: 'Offene Angebote', 
      count: 23, 
      variant: 'warning' as const, 
      Icon: FileText, 
      route: 'angebote',
      trend: { value: 5, label: 'heute' },
      subtitle: '3 ablaufend'
    },
    { 
      title: 'Neue Anfragen', 
      count: 12, 
      variant: 'processing' as const, 
      Icon: MessageSquare, 
      route: 'anfragen',
      trend: { value: 8, label: 'seit gestern' },
    },
    { 
      title: 'Offene Bestellungen', 
      count: 8, 
      variant: 'error' as const, 
      Icon: ShoppingCart, 
      route: 'bestellungen',
      subtitle: '2 überfällig'
    },
    { 
      title: 'Zu versenden', 
      count: 15, 
      variant: 'success' as const, 
      Icon: Package, 
      route: 'versand',
      trend: { value: -3, label: 'vs. gestern' },
    },
    { 
      title: 'OEM Suchen', 
      count: 6, 
      variant: 'processing' as const, 
      Icon: Search, 
      route: 'oem',
      subtitle: '4 dringend'
    },
    { 
      title: 'Rechnungen', 
      count: 34, 
      variant: 'default' as const, 
      Icon: Receipt, 
      route: 'rechnungen',
      trend: { value: 12, label: 'diese Woche' },
    },
  ];

  const columns = [
    {
      key: 'customer',
      header: 'Kunde',
      render: (task: typeof currentTasks[0]) => (
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-[var(--status-success)]" />
          <span>{task.customer}</span>
        </div>
      ),
    },
    {
      key: 'vehicle',
      header: 'Fahrzeug',
      render: (task: typeof currentTasks[0]) => (
        <div className="flex items-center gap-2">
          <Package className="w-4 h-4 text-muted-foreground" />
          <span>{task.vehicle}</span>
        </div>
      ),
    },
    {
      key: 'oem',
      header: 'OEM-Nummer',
      render: (task: typeof currentTasks[0]) => (
        <code className="px-2 py-1 bg-muted rounded text-xs text-mono">
          {task.oem}
        </code>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      render: (task: typeof currentTasks[0]) => (
        <StatusChip status={task.status} label={task.statusLabel} size="sm" />
      ),
    },
    {
      key: 'action',
      header: 'Nächste Aktion',
      align: 'right' as const,
      render: (task: typeof currentTasks[0]) => (
        <Button
          size="sm"
          variant="outline"
          onClick={(e) => {
            e.stopPropagation();
            onNavigate('auftraege');
          }}
        >
          {task.action}
        </Button>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <PageHeader
        title="Heute"
        description="Dein aktueller Arbeitsstand aus WhatsApp, Angeboten und Aufträgen"
      />

      {/* Top Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <MetricCard
          label="WhatsApp Nachrichten"
          value="47"
          change={12}
          changeLabel="vs. gestern"
          icon={<MessageSquare className="w-5 h-5" />}
          variant="primary"
        />
        <MetricCard
          label="Erfolgsrate"
          value="94.2%"
          change={2.3}
          changeLabel="vs. letzte Woche"
          icon={<CheckCircle2 className="w-5 h-5" />}
          variant="success"
        />
        <MetricCard
          label="Ø Antwortzeit"
          value="< 2 Min"
          icon={<Clock className="w-5 h-5" />}
        />
        <MetricCard
          label="Umsatz (heute)"
          value="€2,847"
          change={18}
          changeLabel="vs. gestern"
          icon={<TrendingUp className="w-5 h-5" />}
          variant="success"
        />
      </div>

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column - Chart & Current Tasks Combined */}
        <div className="lg:col-span-2">
          <div className="rounded-xl border border-border bg-card p-6 flex flex-col h-[calc(100vh-220px)]">
            {/* Revenue Chart Section */}
            <div className="flex-shrink-0">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-foreground">Umsatz & Bestellungen</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {timeRange === '7d' && 'Letzte 7 Tage'}
                    {timeRange === '30d' && 'Letzte 30 Tage'}
                    {timeRange === '90d' && 'Letzte 90 Tage'}
                    {timeRange === '1y' && 'Letztes Jahr'}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  {/* Time Range Selector */}
                  <div className="inline-flex items-center rounded-lg border border-border bg-background p-1">
                    <button
                      onClick={() => setTimeRange('7d')}
                      className={`px-3 py-1 text-sm rounded-md transition-all ${
                        timeRange === '7d'
                          ? 'bg-card text-foreground shadow-sm'
                          : 'text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      7T
                    </button>
                    <button
                      onClick={() => setTimeRange('30d')}
                      className={`px-3 py-1 text-sm rounded-md transition-all ${
                        timeRange === '30d'
                          ? 'bg-card text-foreground shadow-sm'
                          : 'text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      30T
                    </button>
                    <button
                      onClick={() => setTimeRange('90d')}
                      className={`px-3 py-1 text-sm rounded-md transition-all ${
                        timeRange === '90d'
                          ? 'bg-card text-foreground shadow-sm'
                          : 'text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      90T
                    </button>
                    <button
                      onClick={() => setTimeRange('1y')}
                      className={`px-3 py-1 text-sm rounded-md transition-all ${
                        timeRange === '1y'
                          ? 'bg-card text-foreground shadow-sm'
                          : 'text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      Jahr
                    </button>
                  </div>

                  {/* Legend */}
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-[var(--status-processing)]"></div>
                      <span className="text-sm text-muted-foreground">Umsatz</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-[var(--status-success)]"></div>
                      <span className="text-sm text-muted-foreground">Bestellungen</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="h-[280px]">
                <RevenueChart data={chartData} />
              </div>
            </div>

            {/* Divider */}
            <div className="border-t border-border my-6 flex-shrink-0"></div>

            {/* Current Tasks Section */}
            <div className="flex-1 flex flex-col min-h-0">
              <h3 className="text-foreground mb-4">Aktuelle Vorgänge</h3>
              <div className="overflow-auto flex-1">
                <DataTable
                  columns={columns}
                  data={currentTasks}
                  onRowClick={() => onNavigate('auftraege')}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Top Customers & Activity Feed */}
        <div className="flex flex-col gap-4 h-[calc(100vh-220px)]">
          <div className="flex-shrink-0 h-[380px]">
            <TopCustomers customers={topCustomers} />
          </div>
          <div className="flex-1 min-h-0">
            <ActivityFeed activities={activities} />
          </div>
        </div>
      </div>
    </div>
  );
}