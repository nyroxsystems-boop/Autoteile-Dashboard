import { useState } from 'react';
import { Search, Filter, Plus, MessageSquare, Clock, FileText, AlertCircle, TrendingUp } from 'lucide-react';
import { CustomerThreadRow } from '../components/CustomerThreadRow';
import { CustomerDetailPanel } from '../components/CustomerDetailPanel';
import { TableDensityToggle, getTableDensityClasses, type TableDensity } from '../components/TableDensityToggle';
import { Sparkline } from '../components/Sparkline';

const mockCustomers = [
  {
    id: '1',
    customerName: 'Mustermann KFZ',
    lastMessage: 'Habe die Teile bekommen, passt perfekt!',
    oemNumbers: ['51717237195', '51717237196'],
    status: 'confirmed' as const,
    timestamp: 'vor 2 Std',
    whatsappNumber: '+49 170 1234567',
    email: 'info@mustermann-kfz.de',
    phone: '+49 30 12345678',
    contactPerson: 'Max Mustermann',
    customerType: 'werkstatt' as const,
    shippingAddress: {
      street: 'Musterstraße 12',
      zip: '10115',
      city: 'Berlin'
    },
    billingAddress: {
      street: 'Musterstraße 12',
      zip: '10115',
      city: 'Berlin'
    },
    deliveryMethod: 'lieferung' as const,
    invoiceRequired: true,
    vatId: 'DE123456789',
    poReference: 'PO-2024-001',
    totalOrders: 42,
    totalRevenue: '€ 18.450',
    messages: [
      {
        id: 'm1',
        sender: 'customer' as const,
        text: 'Hallo, benötige BMW Bremsscheiben',
        timestamp: 'Gestern, 14:23',
        oemNumbers: ['51717237195', '51717237196']
      },
      {
        id: 'm2',
        sender: 'bot' as const,
        text: 'Angebot: 2x Bremsscheibe vorne - € 145,00 | Lieferzeit: 1-2 Tage',
        timestamp: 'Gestern, 14:25'
      },
      {
        id: 'm3',
        sender: 'customer' as const,
        text: 'Habe die Teile bekommen, passt perfekt!',
        timestamp: 'vor 2 Std'
      }
    ]
  },
  {
    id: '6',
    customerName: 'Auto-Center Hoffmann',
    lastMessage: '[Foto gesendet] Brauche dieses Teil',
    oemNumbers: [],
    status: 'oem_pending' as const,
    timestamp: 'vor 5 Min',
    whatsappNumber: '+49 175 9876543',
    contactPerson: 'Klaus Hoffmann',
    customerType: 'werkstatt' as const,
    shippingAddress: {
      street: 'Industriestraße 45',
      zip: '50667',
      city: 'Köln'
    },
    deliveryMethod: 'lieferung' as const,
    invoiceRequired: true,
    vatId: 'DE456789123',
    totalOrders: 18,
    totalRevenue: '€ 8.900',
    messages: [
      {
        id: 'm9',
        sender: 'customer' as const,
        text: '[Foto gesendet] Brauche dieses Teil',
        timestamp: 'vor 5 Min'
      },
      {
        id: 'm10',
        sender: 'bot' as const,
        text: 'Danke! Ich prüfe das Foto kurz. Wenn du schon eine OEM-Nummer hast, schick sie bitte – dann geht\'s schneller.',
        timestamp: 'vor 5 Min'
      }
    ]
  },
  {
    id: '2',
    customerName: 'Schmidt Werkstatt',
    lastMessage: 'Brauche Bremsscheiben für BMW E90',
    oemNumbers: ['34116855152'],
    status: 'in_progress' as const,
    timestamp: 'vor 3 Std',
    whatsappNumber: '+49 171 2345678',
    email: 'schmidt@werkstatt.de',
    contactPerson: 'Peter Schmidt',
    customerType: 'werkstatt' as const,
    shippingAddress: {
      street: 'Hauptstraße 45',
      zip: '80331',
      city: 'München'
    },
    deliveryMethod: 'lieferung' as const,
    invoiceRequired: true,
    vatId: 'DE987654321',
    totalOrders: 28,
    totalRevenue: '€ 12.300',
    messages: [
      {
        id: 'm4',
        sender: 'customer' as const,
        text: 'Brauche Bremsscheiben für BMW E90',
        timestamp: 'vor 3 Std',
        oemNumbers: ['34116855152']
      }
    ]
  },
  {
    id: '3',
    customerName: 'Weber Auto Service',
    lastMessage: 'Hallo, benötige Angebot für Stoßdämpfer',
    oemNumbers: ['33526794463', '33526794464'],
    status: 'quoted' as const,
    timestamp: 'vor 5 Std',
    whatsappNumber: '+49 172 3456789',
    contactPerson: 'Anna Weber',
    customerType: 'partner' as const,
    shippingAddress: {
      street: 'Industriestraße 23',
      zip: '60311',
      city: 'Frankfurt'
    },
    deliveryMethod: 'lieferung' as const,
    invoiceRequired: false,
    totalOrders: 15,
    totalRevenue: '€ 7.890',
    messages: [
      {
        id: 'm5',
        sender: 'customer' as const,
        text: 'Hallo, benötige Angebot für Stoßdämpfer',
        timestamp: 'vor 5 Std',
        oemNumbers: ['33526794463', '33526794464']
      },
      {
        id: 'm6',
        sender: 'bot' as const,
        text: 'Angebot erstellt und versendet',
        timestamp: 'vor 4 Std'
      }
    ]
  },
  {
    id: '4',
    customerName: 'Müller GmbH',
    lastMessage: 'Luftfilter für Mercedes W204',
    oemNumbers: ['2710940404'],
    status: 'new' as const,
    timestamp: 'vor 10 Min',
    whatsappNumber: '+49 173 4567890',
    email: 'kontakt@mueller-gmbh.de',
    phone: '+49 40 98765432',
    contactPerson: 'Thomas Müller',
    customerType: 'endkunde' as const,
    shippingAddress: {
      street: 'Hafenstraße 67',
      zip: '20359',
      city: 'Hamburg'
    },
    deliveryMethod: 'abholung' as const,
    invoiceRequired: false,
    totalOrders: 8,
    totalRevenue: '€ 3.200',
    messages: [
      {
        id: 'm7',
        sender: 'customer' as const,
        text: 'Luftfilter für Mercedes W204',
        timestamp: 'vor 10 Min',
        oemNumbers: ['2710940404']
      }
    ]
  },
  {
    id: '5',
    customerName: 'Fischer Automobile',
    lastMessage: 'Zündkerzen NGK BCPR6ES-11',
    oemNumbers: ['12120037607'],
    status: 'new' as const,
    timestamp: 'vor 25 Min',
    whatsappNumber: '+49 174 5678901',
    contactPerson: 'Lisa Fischer',
    // customerType not set - needs manual assignment
    shippingAddress: {
      street: 'Bahnhofstraße 89',
      zip: '70173',
      city: 'Stuttgart'
    },
    deliveryMethod: 'lieferung' as const,
    invoiceRequired: false,
    totalOrders: 3,
    totalRevenue: '€ 1.450',
    messages: [
      {
        id: 'm8',
        sender: 'customer' as const,
        text: 'Zündkerzen NGK BCPR6ES-11',
        timestamp: 'vor 25 Min',
        oemNumbers: ['12120037607']
      }
    ]
  },
];

export function CustomersInquiriesView() {
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [density, setDensity] = useState<TableDensity>('comfortable');
  const [activeFilter, setActiveFilter] = useState<string | null>(null);

  const selectedCustomer = mockCustomers.find(c => c.id === selectedCustomerId);

  // Filter customers based on active KPI filter
  const filteredCustomers = mockCustomers.filter(customer => {
    const matchesSearch = customer.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.lastMessage.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.oemNumbers.some(oem => oem.includes(searchTerm));
    
    const matchesFilter = !activeFilter || customer.status === activeFilter;
    
    return matchesSearch && matchesFilter;
  });

  const stats = {
    new: mockCustomers.filter(c => c.status === 'new').length,
    in_progress: mockCustomers.filter(c => c.status === 'in_progress').length,
    quoted: mockCustomers.filter(c => c.status === 'quoted').length,
    oem_pending: mockCustomers.filter(c => c.status === 'oem_pending').length,
  };

  const handleFilterClick = (filter: string) => {
    setActiveFilter(activeFilter === filter ? null : filter);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-foreground mb-2">Kunden & Anfragen</h1>
          <p className="text-muted-foreground">
            WhatsApp-Kundenthreads und OEM-Anfragen verwalten
          </p>
        </div>
        <button className="h-10 px-6 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Neue Anfrage
        </button>
      </div>

      {/* KPI Cards - Kompakt */}
      <div className="grid grid-cols-4 gap-6">
        {/* Neue Anfragen - Kompakt */}
        <div 
          onClick={() => handleFilterClick('new')}
          className={`group relative p-4 rounded-xl bg-gradient-to-br from-amber-500/10 via-amber-400/5 to-transparent border hover:border-amber-500/40 backdrop-blur-xl hover:shadow-[0_8px_30px_-5px_rgba(245,158,11,0.25)] hover:-translate-y-0.5 transition-all duration-300 cursor-pointer overflow-hidden ${
            activeFilter === 'new' 
              ? 'border-amber-500/60 shadow-[0_8px_30px_-5px_rgba(245,158,11,0.3)] ring-2 ring-amber-500/30' 
              : 'border-amber-500/20'
          }`}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 via-transparent to-amber-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 shadow-lg shadow-amber-500/25 flex items-center justify-center group-hover:scale-110 transition-all duration-300">
                <MessageSquare className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-green-500/10 border border-green-500/20">
                <TrendingUp className="w-3 h-3 text-green-600" strokeWidth={2.5} />
                <span className="text-xs font-bold text-green-600">+12%</span>
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="text-xs font-semibold text-muted-foreground/80 tracking-wide uppercase">Neue Anfragen</div>
              <div className="text-3xl font-bold bg-gradient-to-br from-amber-600 to-amber-500 bg-clip-text text-transparent tabular-nums tracking-tight">
                {stats.new}
              </div>
            </div>
            
            <div className="mt-2 flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
              12 von heute
            </div>
          </div>
        </div>

        {/* In Bearbeitung - Kompakt */}
        <div 
          onClick={() => handleFilterClick('in_progress')}
          className={`group relative p-4 rounded-xl bg-gradient-to-br from-blue-500/10 via-blue-400/5 to-transparent border hover:border-blue-500/40 backdrop-blur-xl hover:shadow-[0_8px_30px_-5px_rgba(59,130,246,0.25)] hover:-translate-y-0.5 transition-all duration-300 cursor-pointer overflow-hidden ${
            activeFilter === 'in_progress' 
              ? 'border-blue-500/60 shadow-[0_8px_30px_-5px_rgba(59,130,246,0.3)] ring-2 ring-blue-500/30' 
              : 'border-blue-500/20'
          }`}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 via-transparent to-blue-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 shadow-lg shadow-blue-500/25 flex items-center justify-center group-hover:scale-110 transition-all duration-300">
                <Clock className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-green-500/10 border border-green-500/20">
                <TrendingUp className="w-3 h-3 text-green-600" strokeWidth={2.5} />
                <span className="text-xs font-bold text-green-600">+8%</span>
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="text-xs font-semibold text-muted-foreground/80 tracking-wide uppercase">In Bearbeitung</div>
              <div className="text-3xl font-bold bg-gradient-to-br from-blue-600 to-blue-500 bg-clip-text text-transparent tabular-nums tracking-tight">
                {stats.in_progress}
              </div>
            </div>
            
            <div className="mt-2 flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
              4 über 1 Tag alt
            </div>
          </div>
        </div>

        {/* Angebot gesendet - Kompakt */}
        <div 
          onClick={() => handleFilterClick('quoted')}
          className={`group relative p-4 rounded-xl bg-gradient-to-br from-green-500/10 via-green-400/5 to-transparent border hover:border-green-500/40 backdrop-blur-xl hover:shadow-[0_8px_30px_-5px_rgba(34,197,94,0.25)] hover:-translate-y-0.5 transition-all duration-300 cursor-pointer overflow-hidden ${
            activeFilter === 'quoted' 
              ? 'border-green-500/60 shadow-[0_8px_30px_-5px_rgba(34,197,94,0.3)] ring-2 ring-green-500/30' 
              : 'border-green-500/20'
          }`}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 via-transparent to-green-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 to-green-600 shadow-lg shadow-green-500/25 flex items-center justify-center group-hover:scale-110 transition-all duration-300">
                <FileText className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-green-500/10 border border-green-500/20">
                <TrendingUp className="w-3 h-3 text-green-600" strokeWidth={2.5} />
                <span className="text-xs font-bold text-green-600">+15%</span>
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="text-xs font-semibold text-muted-foreground/80 tracking-wide uppercase">Angebot gesendet</div>
              <div className="text-3xl font-bold bg-gradient-to-br from-green-600 to-green-500 bg-clip-text text-transparent tabular-nums tracking-tight">
                {stats.quoted}
              </div>
            </div>
            
            <div className="mt-2 flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              Ø 94% Erfolgsrate
            </div>
          </div>
        </div>

        {/* OEM-Prüfung - Kompakt */}
        <div 
          onClick={() => handleFilterClick('oem_pending')}
          className={`group relative p-4 rounded-xl bg-gradient-to-br from-red-500/10 via-red-400/5 to-transparent border hover:border-red-500/40 backdrop-blur-xl hover:shadow-[0_8px_30px_-5px_rgba(239,68,68,0.25)] hover:-translate-y-0.5 transition-all duration-300 cursor-pointer overflow-hidden ${
            activeFilter === 'oem_pending' 
              ? 'border-red-500/60 shadow-[0_8px_30px_-5px_rgba(239,68,68,0.3)] ring-2 ring-red-500/30' 
              : 'border-red-500/20'
          }`}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 via-transparent to-red-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-500 to-red-600 shadow-lg shadow-red-500/25 flex items-center justify-center group-hover:scale-110 transition-all duration-300">
                <AlertCircle className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-red-500/10 border border-red-500/20">
                <span className="text-xs font-bold text-red-600">⚠️</span>
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="text-xs font-semibold text-muted-foreground/80 tracking-wide uppercase">OEM-Prüfung</div>
              <div className="text-3xl font-bold bg-gradient-to-br from-red-600 to-red-500 bg-clip-text text-transparent tabular-nums tracking-tight">
                {stats.oem_pending}
              </div>
            </div>
            
            <div className="mt-2 flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
              2 dringend
            </div>
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Kunde, OEM oder Nachricht suchen..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full h-10 pl-10 pr-4 rounded-lg border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
          />
        </div>

        {/* Filter */}
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <select
            value={activeFilter || 'all'}
            onChange={(e) => setActiveFilter(e.target.value === 'all' ? null : e.target.value)}
            className="h-10 pl-10 pr-8 rounded-lg border border-border bg-card text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all appearance-none cursor-pointer"
          >
            <option value="all">Alle Status</option>
            <option value="oem_pending">⚠️ OEM-Prüfung</option>
            <option value="new">Neu</option>
            <option value="in_progress">In Bearbeitung</option>
            <option value="quoted">Angebot gesendet</option>
            <option value="confirmed">Bestätigt</option>
          </select>
        </div>

        {/* Table Density */}
        <TableDensityToggle
          density={density}
          onDensityChange={setDensity}
        />
      </div>

      {/* Customer List */}
      <div className="space-y-3">
        {filteredCustomers.map((customer) => (
          <CustomerThreadRow
            key={customer.id}
            customerName={customer.customerName}
            lastMessage={customer.lastMessage}
            oemNumbers={customer.oemNumbers}
            status={customer.status}
            timestamp={customer.timestamp}
            onClick={() => setSelectedCustomerId(customer.id)}
            className={getTableDensityClasses(density)}
          />
        ))}
        {filteredCustomers.length === 0 && (
          <div className="py-16 text-center">
            <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <Search className="w-6 h-6 text-muted-foreground" />
            </div>
            <div className="font-medium text-foreground mb-1">Keine Anfragen gefunden</div>
            <div className="text-sm text-muted-foreground">
              Versuchen Sie es mit anderen Suchbegriffen
            </div>
          </div>
        )}
      </div>

      {/* Customer Detail Panel */}
      {selectedCustomerId && (
        <CustomerDetailPanel
          customer={selectedCustomer as typeof mockCustomers[number]}
          onClose={() => setSelectedCustomerId(null)}
          onCreateQuote={() => {
            setSelectedCustomerId(null);
            // if (onNavigate) {
            //   onNavigate('angebote', selectedCustomerId);
            // }
          }}
        />
      )}
    </div>
  );
}