import { useState } from 'react';
import { Search, Filter, Package, Clock, TrendingUp, CheckCircle2, XCircle, FileText, Plus } from 'lucide-react';
import { Sparkline } from '../components/Sparkline';

interface QuoteOption {
  id: string;
  label: 'A' | 'B' | 'C';
  supplier: string;
  price: number;
  deliveryTime: string;
  stock: string;
  quality: string;
}

interface Quote {
  id: string;
  customerName: string;
  whatsappNumber: string;
  oemNumber: string;
  partName: string;
  timestamp: string;
  status: 'offers_ready' | 'selected' | 'confirmed' | 'rejected';
  selectedOption?: 'A' | 'B' | 'C';
  options: QuoteOption[];
}

const mockQuotes: Quote[] = [
  {
    id: 'Q001',
    customerName: 'Mustermann KFZ',
    whatsappNumber: '+49 170 1234567',
    oemNumber: '51717237195',
    partName: 'Bremsscheibe vorne',
    timestamp: 'vor 10 Min',
    status: 'offers_ready',
    options: [
      {
        id: 'opt-a1',
        label: 'A',
        supplier: 'ATR Autoteile',
        price: 119.99,
        deliveryTime: '1-2 Tage',
        stock: 'Lagernd',
        quality: 'Original'
      },
      {
        id: 'opt-b1',
        label: 'B',
        supplier: 'Premium Parts',
        price: 89.99,
        deliveryTime: '2-3 Tage',
        stock: 'Lagernd',
        quality: 'OEM Quality'
      },
      {
        id: 'opt-c1',
        label: 'C',
        supplier: 'Budget Auto',
        price: 69.99,
        deliveryTime: '3-5 Tage',
        stock: 'Auf Anfrage',
        quality: 'Aftermarket'
      }
    ]
  },
  {
    id: 'Q002',
    customerName: 'Schmidt Werkstatt',
    whatsappNumber: '+49 171 2345678',
    oemNumber: '34116855152',
    partName: 'Bremsscheibe BMW E90',
    timestamp: 'vor 1 Std',
    status: 'selected',
    selectedOption: 'A',
    options: [
      {
        id: 'opt-a2',
        label: 'A',
        supplier: 'ATR Autoteile',
        price: 145.00,
        deliveryTime: '1 Tag',
        stock: 'Lagernd',
        quality: 'Original'
      },
      {
        id: 'opt-b2',
        label: 'B',
        supplier: 'Auto Express',
        price: 129.99,
        deliveryTime: '2 Tage',
        stock: 'Lagernd',
        quality: 'OEM Quality'
      }
    ]
  },
  {
    id: 'Q003',
    customerName: 'Weber Auto Service',
    whatsappNumber: '+49 172 3456789',
    oemNumber: '33526794463',
    partName: 'Stoßdämpfer vorne links',
    timestamp: 'vor 2 Std',
    status: 'confirmed',
    selectedOption: 'B',
    options: [
      {
        id: 'opt-a3',
        label: 'A',
        supplier: 'Premium Parts',
        price: 189.99,
        deliveryTime: '1-2 Tage',
        stock: 'Lagernd',
        quality: 'Sachs Original'
      },
      {
        id: 'opt-b3',
        label: 'B',
        supplier: 'ATR Autoteile',
        price: 159.99,
        deliveryTime: '2-3 Tage',
        stock: 'Lagernd',
        quality: 'Bilstein'
      },
      {
        id: 'opt-c3',
        label: 'C',
        supplier: 'Budget Auto',
        price: 129.99,
        deliveryTime: '3-4 Tage',
        stock: 'Auf Anfrage',
        quality: 'Aftermarket'
      }
    ]
  },
  {
    id: 'Q004',
    customerName: 'Müller GmbH',
    whatsappNumber: '+49 173 4567890',
    oemNumber: '2710940404',
    partName: 'Luftfilter Mercedes W204',
    timestamp: 'vor 3 Std',
    status: 'rejected',
    options: [
      {
        id: 'opt-a4',
        label: 'A',
        supplier: 'Premium Parts',
        price: 39.99,
        deliveryTime: '1 Tag',
        stock: 'Lagernd',
        quality: 'Original'
      }
    ]
  },
];

export function AngeboteView() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<string | null>(null);

  const filteredQuotes = mockQuotes.filter(quote => {
    const matchesSearch = quote.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      quote.oemNumber.includes(searchQuery) ||
      quote.partName.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesFilter = !activeFilter || quote.status === activeFilter;
    
    return matchesSearch && matchesFilter;
  });

  const stats = {
    offers_ready: mockQuotes.filter(q => q.status === 'offers_ready').length,
    selected: mockQuotes.filter(q => q.status === 'selected').length,
    confirmed: mockQuotes.filter(q => q.status === 'confirmed').length,
    rejected: mockQuotes.filter(q => q.status === 'rejected').length,
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-foreground mb-2">Angebote</h1>
          <p className="text-muted-foreground">
            OEM-basierte Angebote erstellen und an Kunden senden
          </p>
        </div>
        <button className="h-10 px-6 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Neues Angebot
        </button>
      </div>

      {/* KPI Cards - Kompakt */}
      <div className="grid grid-cols-4 gap-6">
        {/* Angebote bereit - Kompakt */}
        <div 
          onClick={() => setActiveFilter(activeFilter === 'offers_ready' ? null : 'offers_ready')}
          className={`group relative p-4 rounded-xl bg-gradient-to-br from-amber-500/10 via-amber-400/5 to-transparent border hover:border-amber-500/40 backdrop-blur-xl hover:shadow-[0_8px_30px_-5px_rgba(245,158,11,0.25)] hover:-translate-y-0.5 transition-all duration-300 cursor-pointer overflow-hidden ${ 
            activeFilter === 'offers_ready' 
              ? 'border-amber-500/60 shadow-[0_8px_30px_-5px_rgba(245,158,11,0.3)] ring-2 ring-amber-500/30'
              : 'border-amber-500/20'
          }`}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 via-transparent to-amber-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 shadow-lg shadow-amber-500/25 flex items-center justify-center group-hover:scale-110 transition-all duration-300">
                <FileText className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-green-500/10 border border-green-500/20">
                <TrendingUp className="w-3 h-3 text-green-600" strokeWidth={2.5} />
                <span className="text-xs font-bold text-green-600">+18%</span>
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="text-xs font-semibold text-muted-foreground/80 tracking-wide uppercase">Angebote bereit</div>
              <div className="text-3xl font-bold bg-gradient-to-br from-amber-600 to-amber-500 bg-clip-text text-transparent tabular-nums tracking-tight">
                {stats.offers_ready}
              </div>
            </div>
            
            <div className="mt-2 flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <div className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
              5 ablaufend heute
            </div>
          </div>
        </div>

        {/* Ausgewählt - Kompakt */}
        <div 
          onClick={() => setActiveFilter(activeFilter === 'selected' ? null : 'selected')}
          className={`group relative p-4 rounded-xl bg-gradient-to-br from-blue-500/10 via-blue-400/5 to-transparent border hover:border-blue-500/40 backdrop-blur-xl hover:shadow-[0_8px_30px_-5px_rgba(59,130,246,0.25)] hover:-translate-y-0.5 transition-all duration-300 cursor-pointer overflow-hidden ${ 
            activeFilter === 'selected' 
              ? 'border-blue-500/60 shadow-[0_8px_30px_-5px_rgba(59,130,246,0.3)] ring-2 ring-blue-500/30'
              : 'border-blue-500/20'
          }`}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 via-transparent to-blue-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 shadow-lg shadow-blue-500/25 flex items-center justify-center group-hover:scale-110 transition-all duration-300">
                <CheckCircle2 className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-green-500/10 border border-green-500/20">
                <TrendingUp className="w-3 h-3 text-green-600" strokeWidth={2.5} />
                <span className="text-xs font-bold text-green-600">+22%</span>
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="text-xs font-semibold text-muted-foreground/80 tracking-wide uppercase">Ausgewählt</div>
              <div className="text-3xl font-bold bg-gradient-to-br from-blue-600 to-blue-500 bg-clip-text text-transparent tabular-nums tracking-tight">
                {stats.selected}
              </div>
            </div>
            
            <div className="mt-2 flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
              Wartet auf Bestätigung
            </div>
          </div>
        </div>

        {/* Bestätigt - Kompakt */}
        <div 
          onClick={() => setActiveFilter(activeFilter === 'confirmed' ? null : 'confirmed')}
          className={`group relative p-4 rounded-xl bg-gradient-to-br from-green-500/10 via-green-400/5 to-transparent border hover:border-green-500/40 backdrop-blur-xl hover:shadow-[0_8px_30px_-5px_rgba(34,197,94,0.25)] hover:-translate-y-0.5 transition-all duration-300 cursor-pointer overflow-hidden ${ 
            activeFilter === 'confirmed' 
              ? 'border-green-500/60 shadow-[0_8px_30px_-5px_rgba(34,197,94,0.3)] ring-2 ring-green-500/30'
              : 'border-green-500/20'
          }`}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 via-transparent to-green-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500 to-green-600 shadow-lg shadow-green-500/25 flex items-center justify-center group-hover:scale-110 transition-all duration-300">
                <Package className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-green-500/10 border border-green-500/20">
                <TrendingUp className="w-3 h-3 text-green-600" strokeWidth={2.5} />
                <span className="text-xs font-bold text-green-600">+15%</span>
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="text-xs font-semibold text-muted-foreground/80 tracking-wide uppercase">Bestätigt</div>
              <div className="text-3xl font-bold bg-gradient-to-br from-green-600 to-green-500 bg-clip-text text-transparent tabular-nums tracking-tight">
                {stats.confirmed}
              </div>
            </div>
            
            <div className="mt-2 flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
              Bereit für Bestellung
            </div>
          </div>
        </div>

        {/* Abgelehnt - Kompakt */}
        <div 
          onClick={() => setActiveFilter(activeFilter === 'rejected' ? null : 'rejected')}
          className={`group relative p-4 rounded-xl bg-gradient-to-br from-slate-500/10 via-slate-400/5 to-transparent border hover:border-slate-500/40 backdrop-blur-xl hover:shadow-[0_8px_30px_-5px_rgba(100,116,139,0.2)] hover:-translate-y-0.5 transition-all duration-300 cursor-pointer overflow-hidden ${ 
            activeFilter === 'rejected' 
              ? 'border-slate-500/60 shadow-[0_8px_30px_-5px_rgba(100,116,139,0.3)] ring-2 ring-slate-500/30'
              : 'border-slate-500/20'
          }`}
        >
          <div className="absolute inset-0 bg-gradient-to-br from-slate-500/5 via-transparent to-slate-400/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          <div className="relative z-10">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-slate-500 to-slate-600 shadow-lg shadow-slate-500/20 flex items-center justify-center group-hover:scale-110 transition-all duration-300">
                <XCircle className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-slate-500/10 border border-slate-500/20">
                <span className="text-xs font-bold text-slate-600">-</span>
              </div>
            </div>
            
            <div className="space-y-1">
              <div className="text-xs font-semibold text-muted-foreground/80 tracking-wide uppercase">Abgelehnt</div>
              <div className="text-3xl font-bold bg-gradient-to-br from-slate-700 to-slate-600 bg-clip-text text-transparent tabular-nums tracking-tight">
                {stats.rejected}
              </div>
            </div>
            
            <div className="mt-2 flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <div className="w-1.5 h-1.5 rounded-full bg-slate-500" />
              Archiviert
            </div>
          </div>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Kunde, OEM oder Teil suchen..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-10 pl-10 pr-4 rounded-lg border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
          />
        </div>

        <div className="relative">
          <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <select
            value={activeFilter || 'all'}
            onChange={(e) => setActiveFilter(e.target.value === 'all' ? null : e.target.value)}
            className="h-10 pl-10 pr-8 rounded-lg border border-border bg-card text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all appearance-none cursor-pointer"
          >
            <option value="all">Alle Status</option>
            <option value="offers_ready">Angebote bereit</option>
            <option value="selected">Ausgewählt</option>
            <option value="confirmed">Bestätigt</option>
            <option value="rejected">Abgelehnt</option>
          </select>
        </div>
      </div>

      {/* Quotes List */}
      <div className="space-y-4">
        {filteredQuotes.map((quote) => (
          <div key={quote.id} className="bg-card border border-border rounded-lg p-6 hover:border-primary/50 transition-all">
            {/* Quote Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="font-semibold text-foreground">{quote.customerName}</h3>
                  <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                    quote.status === 'confirmed' 
                      ? 'bg-[var(--status-completed-bg)] text-[var(--status-completed-fg)] border border-[var(--status-completed-border)]'
                      : quote.status === 'selected'
                      ? 'bg-[var(--status-processing-bg)] text-[var(--status-processing-fg)] border border-[var(--status-processing-border)]'
                      : quote.status === 'offers_ready'
                      ? 'bg-[var(--status-waiting-bg)] text-[var(--status-waiting-fg)] border border-[var(--status-waiting-border)]'
                      : 'bg-red-500/10 text-red-600 border border-red-500/20'
                  }`}>
                    {quote.status === 'confirmed' ? '✓ Bestätigt' : 
                     quote.status === 'selected' ? '⏱ Ausgewählt' : 
                     quote.status === 'offers_ready' ? '📋 Angebote bereit' : 
                     '✕ Abgelehnt'}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="font-mono">{quote.oemNumber}</span>
                  <span>•</span>
                  <span>{quote.partName}</span>
                  <span>•</span>
                  <span>{quote.timestamp}</span>
                </div>
              </div>
              {quote.status === 'confirmed' && (
                <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-medium">
                  Auftrag erstellen
                </button>
              )}
            </div>

            {/* Options Grid */}
            <div className="grid grid-cols-3 gap-4">
              {quote.options.map((option) => (
                <div 
                  key={option.id} 
                  className={`p-4 rounded-lg border-2 transition-all ${
                    quote.selectedOption === option.label
                      ? 'border-primary bg-primary/5'
                      : 'border-border bg-muted/30'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className={`w-7 h-7 rounded-full flex items-center justify-center font-semibold text-sm ${
                      quote.selectedOption === option.label
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-muted-foreground'
                    }`}>
                      {option.label}
                    </span>
                    {quote.selectedOption === option.label && (
                      <CheckCircle2 className="w-5 h-5 text-primary" strokeWidth={2} />
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <div className="text-sm font-medium text-foreground">{option.supplier}</div>
                    <div className="text-2xl font-semibold text-foreground tabular-nums">
                      € {option.price.toFixed(2)}
                    </div>
                    
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Clock className="w-3.5 h-3.5" strokeWidth={2} />
                      <span>{option.deliveryTime}</span>
                    </div>
                    
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Package className="w-3.5 h-3.5" strokeWidth={2} />
                      <span>{option.stock}</span>
                    </div>
                    
                    <div className="pt-2 border-t border-border">
                      <span className="text-xs font-medium text-primary">{option.quality}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        {filteredQuotes.length === 0 && (
          <div className="py-16 text-center">
            <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mx-auto mb-4">
              <Search className="w-6 h-6 text-muted-foreground" />
            </div>
            <div className="font-medium text-foreground mb-1">Keine Angebote gefunden</div>
            <div className="text-sm text-muted-foreground">
              Versuchen Sie es mit anderen Suchbegriffen
            </div>
          </div>
        )}
      </div>
    </div>
  );
}