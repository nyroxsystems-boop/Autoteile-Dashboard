import { StatusChip } from '../components/StatusChip';
import { MessageSquare, Store, Activity, Check, FileText, Warehouse } from 'lucide-react';

const systemStatus = [
  {
    id: 1,
    name: 'WhatsApp Bot',
    icon: MessageSquare,
    status: 'online' as const,
    lastUpdate: 'Heute, 15:43 Uhr',
    description: 'Empfängt und verarbeitet Kundenanfragen',
  },
  {
    id: 2,
    name: 'WWS-Anbindung',
    icon: Warehouse,
    status: 'online' as const,
    lastUpdate: 'Heute, 15:40 Uhr',
    description: 'Bestandsdaten und Bestellungen werden synchronisiert',
  },
  {
    id: 3,
    name: 'Belegerzeugung',
    icon: FileText,
    status: 'online' as const,
    lastUpdate: 'Heute, 15:42 Uhr',
    description: 'Rechnungen und Dokumente werden erstellt',
  },
  {
    id: 4,
    name: 'Finanzamt-Übermittlung',
    icon: Activity,
    status: 'online' as const,
    lastUpdate: 'Heute, 14:23 Uhr',
    description: 'Übermittlung erfolgt automatisch',
  },
];

export function StatusView() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1>Status</h1>
        <p className="text-muted-foreground mt-2 leading-relaxed">
          Systemübersicht – Alle Komponenten im Überblick
        </p>
      </div>

      {/* System Components */}
      <div className="grid grid-cols-1 gap-5">
        {systemStatus.map((system) => {
          const Icon = system.icon;
          const isOnline = system.status === 'online';
          
          return (
            <div 
              key={system.id} 
              className="bg-card border border-border rounded-xl p-6 hover:border-border-strong transition-all duration-200"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`
                    w-12 h-12 rounded-xl flex items-center justify-center
                    ${isOnline 
                      ? 'bg-[var(--status-success-bg)] border border-[var(--status-success-border)]' 
                      : 'bg-[var(--status-error-bg)] border border-[var(--status-error-border)]'
                    }
                  `}>
                    <Icon className={`w-6 h-6 ${isOnline ? 'text-[var(--status-success)]' : 'text-[var(--status-error)]'}`} />
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-foreground mb-1">{system.name}</div>
                    <p className="text-sm text-muted-foreground">
                      {system.description}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Letzte Aktualisierung: {system.lastUpdate}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className={`
                    w-2.5 h-2.5 rounded-full
                    ${isOnline ? 'bg-green-500' : 'bg-red-500'}
                  `} 
                  style={{
                    animation: isOnline ? 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite' : 'none'
                  }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* System Health Summary */}
      <div className="bg-[var(--status-success-bg)] border border-[var(--status-success-border)] rounded-xl p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-xl bg-[var(--status-success)] flex items-center justify-center flex-shrink-0">
            <Check className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <div className="font-medium text-foreground mb-2">Alle Systeme funktionsfähig</div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              WhatsApp Bot, WWS-Anbindung, Belegerzeugung und Finanzamt-Übermittlung arbeiten einwandfrei. Uptime: 99.8%
            </p>
          </div>
        </div>
      </div>

      {/* Info Box */}
      <div className="p-5 bg-muted/30 border border-border rounded-xl">
        <p className="text-sm text-muted-foreground leading-relaxed">
          Diese Ansicht zeigt den aktuellen Status aller Systeme. Technische Konfigurationen erfolgen im Admin-Dashboard.
        </p>
      </div>
    </div>
  );
}